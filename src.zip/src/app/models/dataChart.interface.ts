import { Serie } from './serie.interface';
export interface DataChart {
    name: string;
    series: Serie[];
}
