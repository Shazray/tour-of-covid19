export interface Serie {
    name: string;
    value: number;
}
